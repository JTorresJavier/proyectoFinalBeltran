import {
  MatDivider,
  MatDividerModule
} from "./chunk-Q7H6D6QY.js";
import "./chunk-42QFQP6S.js";
import "./chunk-N4DOILP3.js";
import "./chunk-4DLWDFVE.js";
import "./chunk-TN7ZUGLC.js";
import "./chunk-5EALC7RR.js";
import "./chunk-PJVWDKLX.js";
export {
  MatDivider,
  MatDividerModule
};
