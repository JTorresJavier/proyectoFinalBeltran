import {
  MatFormFieldModule
} from "./chunk-WUPWGEW4.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-Y6TYKBN2.js";
import "./chunk-OV2NVKIF.js";
import "./chunk-VON75VBJ.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-42QFQP6S.js";
import "./chunk-AGGACZIN.js";
import "./chunk-DPQ32RIV.js";
import "./chunk-XA6252L2.js";
import "./chunk-N4DOILP3.js";
import "./chunk-6NOVEKIF.js";
import "./chunk-V4HE5JKJ.js";
import "./chunk-WKVXBCUF.js";
import "./chunk-4DLWDFVE.js";
import "./chunk-QGEJTMXZ.js";
import "./chunk-TN7ZUGLC.js";
import "./chunk-JZQDVDL2.js";
import "./chunk-VV7ZWVEV.js";
import "./chunk-X2UBENEG.js";
import "./chunk-VBNZDVWX.js";
import "./chunk-5EALC7RR.js";
import "./chunk-PJVWDKLX.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
